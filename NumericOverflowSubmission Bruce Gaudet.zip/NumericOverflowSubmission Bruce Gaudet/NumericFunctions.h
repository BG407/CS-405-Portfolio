#pragma once
#include <limits>
#include <stdexcept>

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // prevent overflow: if result + increment would exceed max, abort
        if (increment > 0 &&
            result > std::numeric_limits<T>::max() - increment)
        {
            throw std::overflow_error("numeric overflow in add_numbers");
        }

        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // prevent underflow: if result - decrement would go below lowest, abort
        if (decrement > 0 &&
            result < std::numeric_limits<T>::lowest() + decrement)
        {
            throw std::underflow_error("numeric underflow in subtract_numbers");
        }

        result -= decrement;
    }

    return result;
}
