// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid
#include <string>       // std::string
#include <stdexcept>    // std::overflow_error, std::underflow_error
#include <iomanip>      // std::boolalpha
#include "NumericFunctions.h"


// ... existing comments about '+' forcing numeric output ...

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;
    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Adding Numbers Without Overflow
    {
        bool overflowed = false;
        T result = T{};
        try {
            result = add_numbers<T>(start, increment, steps);
        }
        catch (const std::overflow_error&) {
            overflowed = true;
        }
        std::cout << "\tAdding Numbers Without Overflow ("
            << +start << ", " << +increment << ", " << steps << ") => "
            << std::boolalpha << overflowed
            << ", result = " << +result << std::endl;
    }

    // Adding Numbers With Overflow
    {
        bool overflowed = false;
        T result = T{};
        try {
            result = add_numbers<T>(start, increment, steps + 1);
        }
        catch (const std::overflow_error&) {
            overflowed = true;
            // restore last valid value
            result = add_numbers<T>(start, increment, steps);
        }
        std::cout << "\tAdding Numbers With Overflow ("
            << +start << ", " << +increment << ", " << (steps + 1) << ") => "
            << std::boolalpha << overflowed
            << ", result = " << +result << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();
    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Subtracting Numbers Without Underflow
    {
        bool underflowed = false;
        T result = T{};
        try {
            result = subtract_numbers<T>(start, decrement, steps);
        }
        catch (const std::underflow_error&) {
            underflowed = true;
        }
        std::cout << "\tSubtracting Numbers Without Underflow ("
            << +start << ", " << +decrement << ", " << steps << ") => "
            << std::boolalpha << underflowed
            << ", result = " << +result << std::endl;
    }

    // Subtracting Numbers With Underflow
    {
        bool underflowed = false;
        T result = T{};
        try {
            result = subtract_numbers<T>(start, decrement, steps + 1);
        }
        catch (const std::underflow_error&) {
            underflowed = true;
            // restore last valid value
            result = subtract_numbers<T>(start, decrement, steps);
        }
        std::cout << "\tSubtracting Numbers With Underflow ("
            << +start << ", " << +decrement << ", " << (steps + 1) << ") => "
            << std::boolalpha << underflowed
            << ", result = " << +result << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

int main()
{
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;
    return 0;
}
